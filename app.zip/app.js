var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var fs = require("fs");
var multer  = require('multer')
var upload = multer({ dest: '/tmp' })

var bitcore = require('bitcore-lib');
var ECIES = require('bitcore-ecies');
var ethereumUtil = require('ethereumjs-util');
const GitHubApi = require('github');
const github = new GitHubApi({
  debug: true
})

var index = require('./routes/index');
var users = require('./routes/users');

const Web3 = require("web3");
const web3 = new Web3();

var message = "FUBAR";
var appFolder = "/Users/test/work/blockchain/ethereum/ethereum-code/cashVNew/scripts/perfApp";

// [start rpc server on geth console] admin.startRPC(0.0.0.0, 8545)
web3.setProvider(new web3.providers.HttpProvider("http://localhost:8008"));

console.log(web3.eth.coinbase);
console.log('Connected to Ethereum');

/*
var address1 = '0x87f80D8D09B8fA3A67Bbec7688950896F19Bff7D';
var privateKey1 = new bitcore.PrivateKey('1144de4a5af819d52c9e1d444ae77fc227c9436b2c8ad5bcf426511938df98c9');
var publicKey1 = new bitcore.PublicKey.fromPrivateKey(privateKey1); 
//var publicKey1 = bitcore.PublicKey.fromString('0xf327D16118d032bFe3C1012ecdbA3Dc9a8220885', 'hex');
var publicKey1v2 = privateKey1.publicKey;
console.log('publicKey1: ' + publicKey1);
//console.log("pk1: " + Buffer(publicKey1).toString('hex'));
console.log('publicKey1v2: ' + publicKey1v2);

//023bbce1f5 ce3ab35c31 5670777a19 224f810d7b 524ae3b1c3 1236277e00 9822cd

//var publicKey2 = bitcore.PublicKey.fromString('0x61bA371D76cE321d779D9A47c2FDFb3961Bc28F4', 'hex');
var address2 = '0x4A5D105C0C35D349902F8F6e064239B8d10a8bC7';
var privateKey2 = new bitcore.PrivateKey('44cd496e4357fa400d87ecd3954585e1783e518bb58b8fe9e1ebcdabe05c4dd3');
var publicKey2 = new bitcore.PublicKey.fromPrivateKey(privateKey2); 
//var publicKey2 = privateKey2.publicKey;
console.log('publicKey2: ' + publicKey2);
*/

var address1 = ethereumUtil.privateToAddress(Buffer.from('1144de4a5af819d52c9e1d444ae77fc227c9436b2c8ad5bcf426511938df98c9', 'hex'));   
var public1 = ethereumUtil.privateToPublic(Buffer.from('1144de4a5af819d52c9e1d444ae77fc227c9436b2c8ad5bcf426511938df98c9', 'hex')); 

var address2 = ethereumUtil.privateToAddress(Buffer.from('44cd496e4357fa400d87ecd3954585e1783e518bb58b8fe9e1ebcdabe05c4dd3', 'hex'));   
var public2 = ethereumUtil.privateToPublic(Buffer.from('44cd496e4357fa400d87ecd3954585e1783e518bb58b8fe9e1ebcdabe05c4dd3', 'hex')); 

var address3 = ethereumUtil.privateToAddress(Buffer.from('31655bf0d70228a1385e787b9d27f95fd7954369d33695c8bcf1b0c3d06ff0f7', 'hex'));   
var public3 = ethereumUtil.privateToPublic(Buffer.from('31655bf0d70228a1385e787b9d27f95fd7954369d33695c8bcf1b0c3d06ff0f7', 'hex')); 

var hexPublic1 = Buffer(public1).toString('hex');
console.log('public 1: ' + hexPublic1);
console.log('address 1: ' + Buffer(address1).toString('hex') );

console.log('public 2: ' + Buffer(public2).toString('hex') );
console.log('address 2: ' + Buffer(address2).toString('hex') );

console.log('public 3: ' + Buffer(public3).toString('hex') );
console.log('address 3: ' + Buffer(address3).toString('hex') );

var uncompressedPublicKey1 = new bitcore.PublicKey('04'+hexPublic1);







var centralbankAddress = '0x87f80D8D09B8fA3A67Bbec7688950896F19Bff7D';
var boaAddress = '0x4A5D105C0C35D349902F8F6e064239B8d10a8bC7';
var dbAddress = '0x7Ce9425DEA3C9B58C07628D79fc764464f2facba';

var centralBankPrivateKey = '1144de4a5af819d52c9e1d444ae77fc227c9436b2c8ad5bcf426511938df98c9';
var boAPrivateKey = '44cd496e4357fa400d87ecd3954585e1783e518bb58b8fe9e1ebcdabe05c4dd3';
var dbPrivateKey = '31655bf0d70228a1385e787b9d27f95fd7954369d33695c8bcf1b0c3d06ff0f7';

var myId = "DB";
var myAddress= dbAddress;
var myPrivateKey = dbPrivateKey;


var cvContractAbi = [ { "constant": true, "inputs": [], "name": "name", "outputs": [ { "name": "", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "inFileId", "type": "string" } ], "name": "getSingleTransaction", "outputs": [ { "name": "sender", "type": "address", "value": "0x0000000000000000000000000000000000000000" }, { "name": "receiver", "type": "address", "value": "0x0000000000000000000000000000000000000000" }, { "name": "fileId", "type": "string", "value": "" }, { "name": "fileUrl", "type": "string", "value": "" }, { "name": "fileType", "type": "string", "value": "" }, { "name": "referenceId", "type": "string", "value": "" }, { "name": "transactionId", "type": "uint256", "value": "0" }, { "name": "fileHash", "type": "string", "value": "" }, { "name": "time", "type": "uint256", "value": "0" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "totalSupply", "outputs": [ { "name": "", "type": "uint256", "value": "0" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "txSender", "type": "address" }, { "name": "index", "type": "uint256" } ], "name": "getOneSentTransaction", "outputs": [ { "name": "sender", "type": "address" }, { "name": "receiver", "type": "address" }, { "name": "fileId", "type": "string" }, { "name": "fileUrl", "type": "string" }, { "name": "fileType", "type": "string" }, { "name": "referenceId", "type": "string" }, { "name": "transactionId", "type": "uint256" }, { "name": "fileHash", "type": "string" }, { "name": "time", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "refId", "type": "string" }, { "name": "index", "type": "uint256" } ], "name": "getSingleTransactionFromFlow", "outputs": [ { "name": "sender", "type": "address" }, { "name": "receiver", "type": "address" }, { "name": "fileId", "type": "string" }, { "name": "fileUrl", "type": "string" }, { "name": "fileType", "type": "string" }, { "name": "referenceId", "type": "string" }, { "name": "transactionId", "type": "uint256" }, { "name": "fileHash", "type": "string" }, { "name": "time", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [], "name": "complete", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [ { "name": "txReceiver", "type": "address" }, { "name": "index", "type": "uint256" } ], "name": "getOneReceivedTransaction", "outputs": [ { "name": "sender", "type": "address" }, { "name": "receiver", "type": "address" }, { "name": "fileId", "type": "string" }, { "name": "fileUrl", "type": "string" }, { "name": "fileType", "type": "string" }, { "name": "referenceId", "type": "string" }, { "name": "transactionId", "type": "uint256" }, { "name": "fileHash", "type": "string" }, { "name": "time", "type": "uint256" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "bankId", "type": "string" } ], "name": "getMappedAddress", "outputs": [ { "name": "mappedAddr", "type": "address", "value": "0x0000000000000000000000000000000000000000" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "owner", "outputs": [ { "name": "", "type": "address", "value": "0xbfa607862aee8ea14ee8ec908ce1bfa77eebc67f" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "symbol", "outputs": [ { "name": "", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "receiverName", "type": "string" }, { "name": "fileId", "type": "string" }, { "name": "fileUrl", "type": "string" }, { "name": "fileType", "type": "string" }, { "name": "referenceId", "type": "string" }, { "name": "transactionId", "type": "uint256" }, { "name": "fileHash", "type": "string" } ], "name": "cvTransferByName", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [ { "name": "refId", "type": "string" } ], "name": "getNumberOfTransactionInFlow", "outputs": [ { "name": "", "type": "uint256", "value": "0" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "receiver", "type": "address" } ], "name": "getNumberOfReceivedTransaction", "outputs": [ { "name": "", "type": "uint256", "value": "0" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "sender", "type": "address" }, { "name": "receiver", "type": "address" }, { "name": "fileId", "type": "string" }, { "name": "fileUrl", "type": "string" }, { "name": "fileType", "type": "string" }, { "name": "referenceId", "type": "string" }, { "name": "transactionId", "type": "uint256" }, { "name": "fileHash", "type": "string" } ], "name": "cvTransfer", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [ { "name": "", "type": "address" } ], "name": "frozenAccount", "outputs": [ { "name": "", "type": "bool", "value": false } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "sender", "type": "address" } ], "name": "getNumberOfSentTransaction", "outputs": [ { "name": "", "type": "uint256", "value": "0" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "inputs": [ { "name": "nameServerAddtress", "type": "address", "index": 0, "typeShort": "address", "bits": "", "displayName": "name Server Addtress", "template": "elements_input_address" } ], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "payable": false, "stateMutability": "nonpayable", "type": "fallback" }, { "anonymous": false, "inputs": [ { "indexed": true, "name": "sender", "type": "address" }, { "indexed": true, "name": "receiver", "type": "address" }, { "indexed": false, "name": "fileId", "type": "string" }, { "indexed": false, "name": "fileUrl", "type": "string" }, { "indexed": false, "name": "fileType", "type": "string" }, { "indexed": false, "name": "referenceId", "type": "string" }, { "indexed": false, "name": "transactionId", "type": "uint256" }, { "indexed": false, "name": "fileHash", "type": "string" } ], "name": "Transfer", "type": "event" } ];

var cvContractAddress = '0xa1b28c1F7F8C5934E12Db5B44Fb3B6236dDE2757';   
var cvContract = web3.eth.contract(cvContractAbi);
var cvContractInstance = cvContract.at(cvContractAddress);

var event = cvContractInstance.allEvents()
  console.log("listening for events on ", cvContractAddress)
  // watch for changes
  event.watch(function(error, result){ 
    if (!error)
      console.log(result);
  });


var nameServerAddress = '0x6e6ad555A7A65225b8F64509e7AB44fE2Dff3cd0';
var nameServerAbi = [ { "constant": true, "inputs": [ { "name": "bankId", "type": "string" } ], "name": "isBankIdMapped", "outputs": [ { "name": "success", "type": "bool", "value": false } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "bankId", "type": "string" }, { "name": "userAddr", "type": "address" }, { "name": "publicKey", "type": "string" } ], "name": "addMapping", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [ { "name": "bankId", "type": "string" } ], "name": "getMappedAddressAndKey", "outputs": [ { "name": "mappedAddr", "type": "address", "value": "0x0000000000000000000000000000000000000000" }, { "name": "publicKey", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "bankId", "type": "string" } ], "name": "getMappedAddress", "outputs": [ { "name": "mappedAddr", "type": "address", "value": "0x0000000000000000000000000000000000000000" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "addr", "type": "address" } ], "name": "getMappedPublicKey", "outputs": [ { "name": "publicKey", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "addressCount", "outputs": [ { "name": "", "type": "uint256", "value": "3" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "bankId", "type": "string" } ], "name": "getMappedPublicKeyById", "outputs": [ { "name": "publicKey", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "getAddressCount", "outputs": [ { "name": "", "type": "uint256", "value": "3" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [ { "name": "addr", "type": "address" } ], "name": "getMappedBankIdByAddress", "outputs": [ { "name": "bankId", "type": "string", "value": "" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [ { "indexed": false, "name": "bankId", "type": "string" }, { "indexed": false, "name": "userAddr", "type": "address" }, { "indexed": false, "name": "publicKey", "type": "string" } ], "name": "MappingAdded", "type": "event" }, { "anonymous": false, "inputs": [ { "indexed": false, "name": "bankId", "type": "string" }, { "indexed": false, "name": "userAddr", "type": "address" } ], "name": "ShowMappedAddress", "type": "event" } ];
var nameServerContract = web3.eth.contract(nameServerAbi);
var nameServerInstance = nameServerContract.at(nameServerAddress);

// Connect to Neo4J
/*
var neo4j = require('neo4j-driver').v1;

var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "neo4j"));
var session = driver.session();
console.log('Connected to Neo4J');
session.run( "match(m) return m").then( function(result)
{
    console.log(result.records.length);   
});
*/


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/users', users);

app.listen(3008);



app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header('Access-Control-Allow-Credentials', true);
  if ('OPTIONS' === req.method) {
      //respond with 200
      res.send(200);
    }
    else {
    //move on
      next();
    }
});

app.get('/fileUpload.html', function (req, res) {
    res.sendFile(appFolder + "/" + "fileUpload.html" );
})


app.get('/myId', function (req, res) {
    res.send("{\"id\":\"" + myId + "\"}");
})


app.get('/transactionFlow/:refId', function(req, res){

    var numTx = cvContractInstance.getNumberOfTransactionInFlow(req.params.refId);
    var resultList=[];
    for (i = 0; i < numTx; i++) {
        var result = cvContractInstance.getSingleTransactionFromFlow(req.params.refId, i);
        console.log(result);
        var senderAddr = result[0];
        var senderId = nameServerInstance.getMappedBankIdByAddress(senderAddr);
        var receiverAddr = result[1];
        var receiverId = nameServerInstance.getMappedBankIdByAddress(receiverAddr);
        // string fileId, string fileUrl, string fileType, string referenceId, uint256 transactionId, string fileHash, uint time
        var data = {
            sender: senderId, receiver: receiverId, fileId: result[2], fileUrl: result[3], fileType: result[4], referenceId: result[5], 
            transactionId: result[6], fileHash: result[7], time: result[8]
        };
        resultList.push(data);
    }
    res.send(resultList);
})

    
app.post('/fileUploadTmp', upload.single('file'), function (req, res, next) {
    console.log(req.file);
    console.log(req.file.path);
    console.log(req.body.receiverId);
    console.log(req.body.refId);
    
    res.end(req.file.path);
})


app.post('/fileUpload', upload.single('file'), function (req, res, next) {
    console.log(req.file);
    console.log(req.file.path);
    console.log(req.body.receiverId);
    console.log(req.body.refId);
    console.log(req.body.selectedDocType);
    console.log(req.body.selectedReceiver);
    
    var receiverId = req.body.selectedReceiver;
    var refId = req.body.refId;
    var docType = req.body.selectedDocType;
    var resContent = "Error";
    fs.readFile( req.file.path, "ascii", function (err, data) {
        console.log(data);
        resContent = encryptAndSend(data, receiverId, refId, docType);
        if( err ){
            console.log( err );
            resContent = err;
        }
        console.log( resContent );
        res.end( resContent);
    });
})


encryptAndSend = function(content, receiverId, refId, docType) {

    var senderPrivateKey = myPrivateKey;
        var receiverUncompressedPublicKey = nameServerInstance.getMappedPublicKeyById(receiverId);
        var senderPrivateKeyInstance = new bitcore.PrivateKey(senderPrivateKey);

        var patchedReceiverUncompressedPublicKey = receiverUncompressedPublicKey;
        if (receiverUncompressedPublicKey.startsWith('04') == false) {
            patchedReceiverUncompressedPublicKey = '04' + receiverUncompressedPublicKey;
        }

        var receiverUncompressedPublicKeyInstance = new bitcore.PublicKey(patchedReceiverUncompressedPublicKey);

        var sender = ECIES().privateKey(senderPrivateKeyInstance).publicKey(receiverUncompressedPublicKeyInstance);

        var receiverAddress = ethereumUtil.publicToAddress(Buffer.from(receiverUncompressedPublicKey, 'hex'));
        var receiverAddressStr = '0x' + new Buffer(receiverAddress).toString('hex');
      //  var address2 = ethereumUtil.publicToAddress(publicKey2);
        console.log("address of receiver: " + receiverAddressStr);
        
        var senderAddress =  ethereumUtil.privateToAddress(Buffer.from(senderPrivateKey, 'hex')); 
        var senderAddressStr = '0x' + new Buffer(senderAddress).toString('hex');
        console.log("address of sender: " + senderAddressStr);

        var mesgHash = ethereumUtil.sha256(content);
        var mesgHashStr = new Buffer(mesgHash).toString('hex');
        console.log("Mesg Hash: " + mesgHashStr);
        
        var encrypted = sender.encrypt(content);
      //  console.log("encrypted: " + encrypted);

        var contentToBeSaved = new Buffer(encrypted).toString('base64')
     //   console.log("Base64: " + contentToBeSaved);
        

        github.authenticate({
          type: 'oauth',
          token: '2a3da6e7dcf9d03112d5ecef26f2fee594464818'
        })

        var fileId = makeid(16);
        github.repos.createFile({
          owner: 'visibilitydash',
          repo: 'cv',
          path: fileId,
          message: docType,
          content: contentToBeSaved // base64-encoded "bleep bloop"
        })
        
        var fileUrl = "https://github.com/VisibilityDash/cv/blob/master/" + fileId;
        
        /*
            cvTransfer(address sender, address receiver, string fileId, string fileUrl, string fileType, uint256 transactionId, string fileHash)
        */
        var result = cvContractInstance.cvTransferByName.sendTransaction(receiverId, fileId, fileUrl, docType, refId, 0, mesgHashStr, {from: myAddress, gas: 3000000});

        var resContent = "{ 'url' : 'https://github.com/VisibilityDash/cv/blob/master/" + fileId + "?raw=true', 'fileId' : '" + fileId + "'}";
        
        console.log(resContent);
        return resContent;
   
}


createDescryptionErrorMessage = function(errorMessage)
{
    var resContent = "{\"fileContent\":\"\", \"errorMessage\":\"" + errorMessage + "\"}";
    return resContent;
}

function escapeRegExp(str) {
    return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}

function replaceAll(str, find, replace) {
    return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

createDescryptionContentMessage = function(contentMessage)
{
    //contentMessage = replaceAll(contentMessage, "\"", "'");
    contentMessage = contentMessage.replace(new RegExp('\"', 'g'), '\'');
    var resContent = "{\"errorMessage\":\"Success\", \"fileContent\":\"" + contentMessage + "\"}";
    return resContent;
}


app.post('/encryptFile/:receiverId/:refId', function (req, res) {

    console.log("in encryptFile");
    
    var size = 0;
    var content="";

    req.on('data', function (data) {
        size += data.length;
        content = content+data;
        console.log('Got chunk: ' + data.length + ' total: ' + size);
    });

    req.on('end', function () {

        //console.log("incoming: " + content);
        
        var receiverId = req.params.receiverId;
        console.log("receiverId: " + receiverId);
        
        var senderPrivateKey = myPrivateKey;
        var receiverUncompressedPublicKey = nameServerInstance.getMappedPublicKeyById(receiverId);
        var senderPrivateKeyInstance = new bitcore.PrivateKey(senderPrivateKey);

        var patchedReceiverUncompressedPublicKey = receiverUncompressedPublicKey;
        if (receiverUncompressedPublicKey.startsWith('04') == false) {
            patchedReceiverUncompressedPublicKey = '04' + receiverUncompressedPublicKey;
        }

        var receiverUncompressedPublicKeyInstance = new bitcore.PublicKey(patchedReceiverUncompressedPublicKey);

        var sender = ECIES().privateKey(senderPrivateKeyInstance).publicKey(receiverUncompressedPublicKeyInstance);

        var receiverAddress = ethereumUtil.publicToAddress(Buffer.from(receiverUncompressedPublicKey, 'hex'));
        var receiverAddressStr = '0x' + new Buffer(receiverAddress).toString('hex');
      //  var address2 = ethereumUtil.publicToAddress(publicKey2);
        console.log("address of receiver: " + receiverAddressStr);
        
        var senderAddress =  ethereumUtil.privateToAddress(Buffer.from(senderPrivateKey, 'hex')); 
        var senderAddressStr = '0x' + new Buffer(senderAddress).toString('hex');
        console.log("address of sender: " + senderAddressStr);

        var mesgHash = ethereumUtil.sha256(content);
        var mesgHashStr = new Buffer(mesgHash).toString('hex');
        console.log("Mesg Hash: " + mesgHashStr);
        
        var encrypted = sender.encrypt(content);
      //  console.log("encrypted: " + encrypted);

        var contentToBeSaved = new Buffer(encrypted).toString('base64')
     //   console.log("Base64: " + contentToBeSaved);
        

        github.authenticate({
          type: 'oauth',
          token: '2a3da6e7dcf9d03112d5ecef26f2fee594464818'
        })

        var fileId = makeid(16);
        github.repos.createFile({
          owner: 'visibilitydash',
          repo: 'cv',
          path: fileId,
          message: 'WTE checked in',
          content: contentToBeSaved // base64-encoded "bleep bloop"
        })
        
        var fileUrl = "https://github.com/VisibilityDash/cv/blob/master/" + fileId;
        
        /*
            cvTransfer(address sender, address receiver, string fileId, string fileUrl, string fileType, uint256 transactionId, string fileHash)
        */
        var result = cvContractInstance.cvTransferByName.sendTransaction(req.params.receiverId, fileId, fileUrl, "WTE", req.params.refId, 0, mesgHashStr, {from: myAddress, gas: 3000000});

        var resContent = "{ 'url' : 'https://github.com/VisibilityDash/cv/blob/master/" + fileId + "?raw=true', 'fileId' : '" + fileId + "'}";
        
        console.log(resContent);
        res.end(resContent);

    }); 

    req.on('error', function(e) {
        console.log("ERROR ERROR: " + e.message);
        res.send("error");
    });

})


app.get('/decryptFile/:senderId/:fileId', function(req, res){
    
     github.repos.getContent({
          owner: 'visibilitydash',
          repo: 'cv',
          path: req.params.fileId
        }, function (err, resp) {
            if (err) {
                console.log(err.message);
                res.send(createDescryptionErrorMessage(err.message));
                throw err;
            }
            try {
               // console.log("Base64: " + resp.data.content);

                var uintArray = new Buffer(resp.data.content, 'base64'); 


                var receiverPrivateKey = myPrivateKey;
                var senderUncompressedPublicKey = nameServerInstance.getMappedPublicKeyById(req.params.senderId);
                var receiverPrivateKeyInstance = new bitcore.PrivateKey(receiverPrivateKey);

                var patchedSenderUncompressedPublicKey = senderUncompressedPublicKey;
                if (senderUncompressedPublicKey.startsWith('04') == false) {
                    patchedSenderUncompressedPublicKey = '04' + senderUncompressedPublicKey;
                }

                var senderUncompressedPublicKeyInstance = new bitcore.PublicKey(patchedSenderUncompressedPublicKey);

                var receiver = ECIES().privateKey(receiverPrivateKeyInstance).publicKey(senderUncompressedPublicKeyInstance);

                var decrypted = receiver.decrypt(uintArray).toString();

                // TODO:   1. Recompute the mesg hash, 2. get the saved hash from the blockchain, 3. compare the hashes
                var mesgHash = ethereumUtil.sha256(decrypted);
                var calculatedMesgHash = new Buffer(mesgHash).toString('hex');
                console.log("Calculated Mesg Hash: " + calculatedMesgHash);
                
                var txInfo = cvContractInstance.getSingleTransaction(req.params.fileId);
                console.log("txInfo: " + txInfo);
                var txInfoComp = String(txInfo).split(',');
                console.log("Saved Mesg Hsh: " + txInfoComp[7])
                if (calculatedMesgHash.localeCompare(txInfoComp[7]) != 0) {
                    res.send(createDescryptionErrorMessage("Content hash does not match"));
                }
                else {
                    console.log(createDescryptionErrorMessage("Content hashes match"));
                }

                console.log("decrypted: " + decrypted);
                res.send(createDescryptionContentMessage(decrypted));
               // console.log(JSON.stringify(resp))
            }
            catch(err) {
                console.log(err.message);
                res.send(createDescryptionErrorMessage(err.message));
            }
     });
    
});



// for testing http://localhost:3000/encryptFile/e81860be7f465333229cd01f915ccf0f81ddcf396588c5694fd606a57016fc50/656a0ffb652354ef3cc2d1ac8f1d748ef6be2d7c33b8689dda1aecac3e2cbd631538dde06a12ba6eee895c1f173c45d43bbe320818bb048a4977b1ebdfdeec78
app.post('/encryptFileOld/:senderPrivateKey/:receiverUncompressedPublicKey', function (req, res) {


    var size = 0;
    var content="";

    req.on('data', function (data) {
        size += data.length;
        content = content+data;
      //  console.log('Got chunk: ' + data.length + ' total: ' + size);
    });

    req.on('end', function () {
     //   console.log("total size = " + size);
        console.log("incoming: " + content);
        
        var senderPrivateKey = req.params.senderPrivateKey;
        var receiverUncompressedPublicKey = req.params.receiverUncompressedPublicKey;
        var senderPrivateKeyInstance = new bitcore.PrivateKey(senderPrivateKey);

        var patchedReceiverUncompressedPublicKey = receiverUncompressedPublicKey;
        if (receiverUncompressedPublicKey.startsWith('04') == false) {
            patchedReceiverUncompressedPublicKey = '04' + receiverUncompressedPublicKey;
        }

        var receiverUncompressedPublicKeyInstance = new bitcore.PublicKey(patchedReceiverUncompressedPublicKey);

        var sender = ECIES().privateKey(senderPrivateKeyInstance).publicKey(receiverUncompressedPublicKeyInstance);

        var receiverAddress = ethereumUtil.publicToAddress(Buffer.from(receiverUncompressedPublicKey, 'hex'));
        var receiverAddressStr = '0x' + new Buffer(receiverAddress).toString('hex');
      //  var address2 = ethereumUtil.publicToAddress(publicKey2);
        console.log("address of receiver: " + receiverAddressStr);
        
        var senderAddress =  ethereumUtil.privateToAddress(Buffer.from(senderPrivateKey, 'hex')); 
        var senderAddressStr = '0x' + new Buffer(senderAddress).toString('hex');
        console.log("address of sender: " + senderAddressStr);

        var mesgHash = ethereumUtil.sha256(content);
        var mesgHashStr = new Buffer(mesgHash).toString('hex');
        console.log("Mesg Hash: " + mesgHashStr);
        
        var encrypted = sender.encrypt(content);
      //  console.log("encrypted: " + encrypted);

        var contentToBeSaved = new Buffer(encrypted).toString('base64')
     //   console.log("Base64: " + contentToBeSaved);
        

        github.authenticate({
          type: 'oauth',
          token: '2a3da6e7dcf9d03112d5ecef26f2fee594464818'
        })

        var fileId = makeid(16);
        github.repos.createFile({
          owner: 'visibilitydash',
          repo: 'cv',
          path: fileId,
          message: 'WTE checked in',
          content: contentToBeSaved // base64-encoded "bleep bloop"
        })
        
        var fileUrl = "https://github.com/VisibilityDash/cv/blob/master/" + fileId;
        
        /*
            cvTransfer(address sender, address receiver, string fileId, string fileUrl, string fileType, uint256 transactionId, string fileHash)
        */
        var result = cvContractInstance.cvTransfer.sendTransaction(senderAddressStr, receiverAddressStr, fileId, fileUrl, "WTE", 0, mesgHashStr, {from: centralbankAddress, gas: 1000000});

        var resContent = "{ 'url' : 'https://github.com/VisibilityDash/cv/blob/master/" + fileId + "?raw=true', 'fileId' : '" + fileId + "'}";
        
        console.log(resContent);
        res.end(resContent);

    }); 

    req.on('error', function(e) {
        console.log("ERROR ERROR: " + e.message);
        res.send("error");
    });

})

// for testing http://localhost:3000/decryptFile/e72acfe03abe9fc43886175bbad4182d53e410737c1143581bbc695aa0df09ca/3bbce1f5ce3ab35c315670777a19224f810d7b524ae3b1c31236277e009822cd78e18ea06611b597360b13b99bb527f2b2813ab402682fa403e85b5f2d67f2ce/JEeW5
app.get('/decryptFileOld/:receiverPrivateKey/:senderUncompressedPublicKey/:fileId', function(req, res){
    
     github.repos.getContent({
          owner: 'visibilitydash',
          repo: 'cv',
          path: req.params.fileId
        }, function (err, resp) {
            if (err) {
                console.log(err.message);
                res.send(err.message);
                throw err;
            }
            try {
               // console.log("Base64: " + resp.data.content);

                var uintArray = new Buffer(resp.data.content, 'base64'); 


                var receiverPrivateKey = req.params.receiverPrivateKey;
                var senderUncompressedPublicKey = req.params.senderUncompressedPublicKey;
                var receiverPrivateKeyInstance = new bitcore.PrivateKey(receiverPrivateKey);

                var patchedSenderUncompressedPublicKey = senderUncompressedPublicKey;
                if (senderUncompressedPublicKey.startsWith('04') == false) {
                    patchedSenderUncompressedPublicKey = '04' + senderUncompressedPublicKey;
                }

                var senderUncompressedPublicKeyInstance = new bitcore.PublicKey(patchedSenderUncompressedPublicKey);

                var receiver = ECIES().privateKey(receiverPrivateKeyInstance).publicKey(senderUncompressedPublicKeyInstance);

                var decrypted = receiver.decrypt(uintArray).toString();

                // TODO:   1. Recompute the mesg hash, 2. get the saved hash from the blockchain, 3. compare the hashes
                var mesgHash = ethereumUtil.sha256(decrypted);
                var calculatedMesgHash = new Buffer(mesgHash).toString('hex');
                console.log("Calculated Mesg Hash: " + calculatedMesgHash);
                
                var txInfo = cvContractInstance.getSingleTransaction(req.params.fileId);
                console.log("txInfo: " + txInfo);
                var txInfoComp = String(txInfo).split(',');
                console.log("Saved Mesg Hsh: " + txInfoComp[6])
                if (calculatedMesgHash.localeCompare(txInfoComp[6]) != 0) {
                    res.send("Content hash does not match");
                }
                else {
                    console.log("Content hashes match");
                }

                console.log("decrypted: " + decrypted);
                res.send(decrypted);
               // console.log(JSON.stringify(resp))
            }
            catch(err) {
                console.log(err.message);
                res.send(err.message);
            }
     });
    
});




// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

function makeid(idSize) {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < idSize; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));
    
   return text;
 
    /*
    var d = new Date();
    var n = d.getTime();
    
    return n;
    */
}

module.exports = app;
