import {Component} from '@angular/core';
import {DemoService} from './demo.service';
import {Observable} from 'rxjs/Rx';
import { FileUploader } from 'ng2-file-upload';

@Component({
  selector: 'demo-app',
  template:`
  <h1>Cash Blockchain Viewer</h1>
  <p>Cash Visibiility Info on Blockchain</p>
  
  
  <h3>Transaction Flow</h3>
    Transaction Reference Id: <input type="text" [(ngModel)]="iRefId"> <br>
    <button type="button" (click)="doRetrieveFlow();">
      Search
    </button>
    
    <table>
      <tr>
        <th>Sender</th>
        <th>Receipient</th>
        <th>File Id</th>
        <th>Time</th>
      </tr>
      <tr *ngFor="let tx of transactionFlow">
        <td>{{ tx.sender}}</td>
        <td>{{ tx.receiver}}</td>
        <td>{{ tx.fileId}}</td>
        <td>{{ tx.time*1000 | date : "MMM d, y h:mm:ss a"}}</td>
      </tr>
  </table>
  
  <h3>Upload File</h3>
  <div ng2FileDrop  [uploader]="uploader"></div>
    <input type="file" ng2FileSelect [uploader]="uploader" single /><br>
    Receiver Id: <input type="text" [(ngModel)]="receiverId"> <br>
    Transactiuon Reference Id: <input type="text" [(ngModel)]="refId"><br>
    <button type="button" (click)="doUpload();">
      Upload
    </button>

<!--
<h3>Upload queue</h3>
            <p>Queue length: {{ uploader?.queue?.length }}</p>
 
            <table class="table">
                <thead>
                <tr>
                    <th width="50%">Name</th>
                    <th>Size</th>
                    <th>Progress</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <tr *ngFor="let item of uploader.queue">
                    <td><strong>{{ item?.file?.name }}</strong></td>
                    <td *ngIf="uploader.isHTML5" nowrap>{{ item?.file?.size/1024/1024 | number:'.2' }} MB</td>
                    <td *ngIf="uploader.isHTML5">
                        <div class="progress" style="margin-bottom: 0;">
                            <div class="progress-bar" role="progressbar" [ngStyle]="{ 'width': item.progress + '%' }"></div>
                        </div>
                    </td>
                    <td class="text-center">
                        <span *ngIf="item.isSuccess"><i class="glyphicon glyphicon-ok"></i></span>
                        <span *ngIf="item.isCancel"><i class="glyphicon glyphicon-ban-circle"></i></span>
                        <span *ngIf="item.isError"><i class="glyphicon glyphicon-remove"></i></span>
                    </td>
                    <td nowrap>
                        <button type="button" class="btn btn-success btn-xs"
                                (click)="item.upload()" [disabled]="item.isReady || item.isUploading || item.isSuccess">
                            <span class="glyphicon glyphicon-upload"></span> Upload
                        </button>
                        <button type="button" class="btn btn-warning btn-xs"
                                (click)="item.cancel()" [disabled]="!item.isUploading">
                            <span class="glyphicon glyphicon-ban-circle"></span> Cancel
                        </button>
                        <button type="button" class="btn btn-danger btn-xs"
                                (click)="item.remove()">
                            <span class="glyphicon glyphicon-trash"></span> Remove
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
-->
  `
})
export class AppComponent {


  public transactionFlow;
  public uploader;
  public refId;
  public receiverId;
  public iRefId;

  public food_name;

  constructor(private _demoService: DemoService) {

  }

  ngOnInit() {
   // this.getTransactionFlow('2-10-1');       
    this.uploader = new FileUploader({url: `http://localhost:3008/fileUpload`});
    
  }
  
  getTransactionFlow(txRefId) {
    this._demoService.getTransactionFlow(txRefId).subscribe(
      // the first argument is a function which runs on success
      data => { this.transactionFlow = data},
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading transactionFlow')
    );
  }
  
  
  doUpload()
  {
    console.log("in doUpload");
    this.uploader.onBuildItemForm = (item, form) => {
      form.append("receiverId", this.receiverId);
      form.append("refId", this.refId);
    };
    var item = this.uploader.queue;
    console.log(this.uploader.queue);
    console.log("refId = " + this.refId + ", receiverId = " + this.receiverId);
    console.log(item[0].upload());
  }
  
  doRetrieveFlow()
  {
    console.log("In rFlow");
    this.getTransactionFlow(this.iRefId);
  }


}
