import { Injectable } from "@angular/core";


@Injectable()
export class Globals {

    role: string = 'test';
    urlRoot: string = 'http://localhost:3008';
    
    docType = ['WTE', 'e-Receipt'];
    receivers = ['Fed', 'DB', 'BoA', 'WF'];

}